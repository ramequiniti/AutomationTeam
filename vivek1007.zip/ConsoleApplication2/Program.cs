﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Support.UI;

namespace ConsoleApplication2
{
    class Program
    {
        static void Main(string[] args)
        {
            IWebDriver driver = new ChromeDriver();
            driver.Manage().Window.Maximize();
            driver.Navigate().GoToUrl("http://automationpractice.com");

            //Registration
            driver.FindElement(By.PartialLinkText("Sign in")).Click();            
            Random randomGenerator = new Random();
            int randomInt = randomGenerator.Next(100, 1000);
            driver.FindElement(By.Name("email_create")).SendKeys("Vivek" + randomInt + "@gmail.com");
            driver.FindElement(By.Id("SubmitCreate")).Click();
            driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(3);
            driver.FindElement(By.Id("id_gender1")).Click();
            driver.FindElement(By.Id("customer_firstname")).SendKeys("Vivekraj");
            driver.FindElement(By.Id("customer_lastname")).SendKeys("Pugalendhi");
            driver.FindElement(By.Id("passwd")).SendKeys("Welcome@123");            
            SelectElement Days = new SelectElement(driver.FindElement(By.Id("days")));
            SelectElement Months = new SelectElement(driver.FindElement(By.Id("months")));
            SelectElement Years = new SelectElement(driver.FindElement(By.Id("years")));
            Days.SelectByValue("1");
            Months.SelectByValue("7");
            Years.SelectByValue("1990");
            driver.FindElement(By.Id("firstname")).SendKeys("Vivekraj");
            driver.FindElement(By.Id("lastname")).SendKeys("Pugalendhi");
            driver.FindElement(By.Id("company")).SendKeys("Allstate");
            driver.FindElement(By.Id("address1")).SendKeys("123 abc");
            driver.FindElement(By.Id("city")).SendKeys("Chennai");
            SelectElement State = new SelectElement(driver.FindElement(By.Id("id_state")));
            State.SelectByText("Wisconsin");
            driver.FindElement(By.Id("postcode")).SendKeys("53001");
            driver.FindElement(By.Id("phone_mobile")).SendKeys("9566545838");
            driver.FindElement(By.Id("alias")).SendKeys("Testing");
            driver.FindElement(By.Id("submitAccount")).Click();
            driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(2);

            //Verifying & adding to Wishlist
            driver.FindElement(By.XPath("//*[@id='header']/div[2]/div/div/nav/div[1]/a/span")).Text.Contains("Vivekraj Pugalendhi");
            driver.FindElement(By.XPath("//*[@id='center_column']/div/div[2]/ul/li/a/span")).Click();
            driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(2);
            driver.FindElements(By.ClassName("product-name"))[1].Click();
            driver.FindElement(By.Id("wishlist_button")).Click();
            driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(2);
            driver.FindElement(By.ClassName("fancybox-error")).Text.Contains("Added to your wishlist.");
            driver.FindElement(By.CssSelector("#product > div.fancybox-overlay.fancybox-overlay-fixed > div > div > a")).Click();
            driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(2);

            //Verifying Wishlist
            driver.FindElement(By.XPath("//*[@id='header']/div[2]/div/div/nav/div[1]/a/span")).Click();
            driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(2); 
            driver.FindElement(By.XPath("//*[@id='center_column']/div/div[2]/ul/li/a/span")).Click();
            driver.FindElement(By.ClassName("wishlist_delete")).Displayed.Equals(1);

            driver.Quit();
            // We can Parameterize by using excel for multiple users


        }
    }
}
