﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Newtonsoft.Json;
using System.Web;
using System.Net;
using System.IO;

namespace TestApplication
{

    public class AddCustomerScript

    {
        string connstring;

        public string email;
        public string samplejson;
        JSONModel model = new JSONModel();
        IWebDriver driver = new ChromeDriver(@"C:\Users\Admin\Desktop\Testing");
        SqlConnection con;
                
        SqlCommand com;
        SqlDataReader reader;
        

// SQL connection

            public void dbvalidation()
        {
            con = new SqlConnection(connstring);
            connstring = ("datasource, dbname, un, pwd");
            con.Open();
            string query = "select * from tablename where id= 1";
            com = new SqlCommand(query, con);
            reader = com.ExecuteReader();
            
            
        }


//selenium
        public void createaccunt (string emailid)
        {
            
            driver.Navigate().GoToUrl("");
            IWebElement signin = driver.FindElement(By.LinkText("sign In"));
            signin.Click();
            email = emailid;
            IWebElement mail = driver.FindElement(By.Id(""));
            mail.SendKeys(emailid);
            IWebElement createbtn = driver.FindElement(By.ClassName(""));
            createbtn.Click();
        
        }

        public void wishlist()
        {
            IWebElement wish = driver.FindElement(By.LinkText("MY WISHLISTS"));
            wish.Click();
            IWebElement sellers = driver.FindElement(By.LinkText("TOP SELLERS"));
            sellers.Click();

        }

        //Serialize JSON
        public string registration(string tit, string FN, string ln, int pin)
        {

           // string samplejson = JsonConvert.SerializeObject(model);
            model.title = tit;
            model.firstname = FN;
            model.Lastname = ln;
            model.code = pin;
             samplejson = JsonConvert.SerializeObject(model);
            return samplejson;
        }

//Model Class
        public class JSONModel
        {

            public string title { get; set; }
            public string firstname { get; set;}
            public string Lastname { get; set; }
            public int code { get; set; }
        }

//Post the data
        public void HitApi(string url)
        {
            HttpWebRequest req =  (HttpWebRequest)WebRequest.Create(url);
            req.Method = "POST";
            req.ContentType = "application/json";
            //StreamWriter requestWriter = new StreamWriter(req.GetRequestStream(), System.Text.Encoding.ASCII);
            //requestWriter.Write(samplejson);

            WebResponse response = req.GetResponse();
            Stream webStream = response.GetResponseStream();
            StreamReader responseReader = new StreamReader(webStream);
            string data = responseReader.ReadToEnd();



        }
    }
}
