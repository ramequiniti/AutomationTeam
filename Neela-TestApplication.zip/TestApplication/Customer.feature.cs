﻿#error Version conflict - SpecFlow Visual Studio extension attempted to use SpecFlow code-behind generator 1.9, but project 'TestApplication' references SpecFlow 3.0.
#error We recommend migrating to MSBuild code-behind generation to resolve this issue.
#error For more information see https://specflow.org/documentation/Generate-Tests-from-MsBuild/