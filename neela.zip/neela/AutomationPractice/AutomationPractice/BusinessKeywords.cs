﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using System.Threading;
using OpenQA.Selenium.Support.UI;

namespace AutomationPractice
{
    
    public class BusinessKeywords
    {
        public static IWebDriver driver;
        public static void LaunchBrowser()
        {
            driver = new ChromeDriver();
            driver.Navigate().GoToUrl("http://automationpractice.com");
            driver.Manage().Window.Maximize();
        }

        public static void SigintoHomePage(String mailid, String password)
        {            
            try
            {
                //clicking sigin Button
                driver.FindElement(By.XPath("//header[@id='header']/div[2]/div/div/nav/div[1]/a")).Click();
                Thread.Sleep(1500);

                //Sigin to the Account..
                driver.FindElement(By.XPath("//input[@id='email']")).SendKeys(mailid);
                driver.FindElement(By.XPath("//input[@id='passwd']")).SendKeys(password);
                driver.FindElement(By.XPath("//button[@id='SubmitLogin']")).Click();
                Thread.Sleep(1500);
                try
                {
                    Boolean check = driver.FindElement(By.XPath("//li[contains(text(),'Authentication failed')]")).Displayed;
                    //if account is already added , then if loop begins
                    if (check)
                    {
                        //Creating new Account..

                        driver.FindElement(By.XPath("//input[@id='email_create']")).SendKeys(mailid);
                        driver.FindElement(By.XPath("//button[@id='SubmitCreate']")).Click();

                        Thread.Sleep(1500);
                        driver.FindElement(By.XPath("//input[@id='id_gender1']")).Click();

                        driver.FindElement(By.XPath("//input[@id='customer_firstname']")).SendKeys("Neelavathi");
                        driver.FindElement(By.XPath("//input[@id='customer_lastname']")).SendKeys("Maruthachalam");
                        driver.FindElement(By.XPath("//input[@id='passwd']")).SendKeys(password);
                        driver.FindElement(By.XPath("//input[@id='address1']")).SendKeys("kovilambakkam");
                        driver.FindElement(By.XPath("//input[@id='city']")).SendKeys("Chennai");


                        SelectElement select = new SelectElement(driver.FindElement(By.Id("id_state")));
                        select.SelectByValue("2");
                        Thread.Sleep(1500);

                        driver.FindElement(By.XPath("//input[@id='postcode']")).SendKeys("9800");
                        driver.FindElement(By.XPath("//input[@id='phone_mobile']")).SendKeys("1456");
                        driver.FindElement(By.XPath("//input[@id='alias']")).SendKeys("test123@gmail.com");
                        driver.FindElement(By.XPath("//button[@id='submitAccount']")).Click();

                        Thread.Sleep(2500);
                        //Sigin to the Account..
                        driver.FindElement(By.XPath("//input[@id='email']")).SendKeys(mailid);
                        driver.FindElement(By.XPath("//input[@id='passwd']")).SendKeys(password);
                        driver.FindElement(By.XPath("//button[@id='SubmitLogin']")).Click();
                        Thread.Sleep(1500);
                    }
                }
                catch (Exception)
                {
                    Console.WriteLine("Already Addeed");
                }

            }
            catch (Exception)
            {
                Assert.IsTrue(false);
            }
        }

        public static void SearchForDress()
        {
            try
            {
                driver.FindElement(By.XPath("//input[@id='search_query_top']")).SendKeys("dress");
                driver.FindElement(By.XPath("//form[@id='searchbox']/button")).Click();
                Thread.Sleep(2500);
                String itemfound = "";
                int count = driver.FindElements(By.XPath("//*[@id='center_column']/ul/li")).Count;
                {
                    if (count == 0)
                    {
                        Console.WriteLine("there is no item found to add to whishlist");
                    }
                    else
                    {
                        for (int index = 1; index <= count;)
                        {
                            String srcText = driver.FindElement(By.XPath("//*[@id='center_column']/ul/li[" + index + "]/div/div/div/a[1]/img")).GetAttribute("src");
                            String title = driver.FindElement(By.XPath("//*[@id='center_column']/ul/li[" + index + "]/div/div/div/a[1]/img")).GetAttribute("Title");
                            String description = driver.FindElement(By.XPath("//*[@id='center_column']/ul/li[1]//p")).Text;
                            String price = driver.FindElement(By.XPath("//*[@id='center_column']/ul/li[" + index + "]/div/div[2]/div[1]/span[2]")).Text;
                            driver.FindElement(By.XPath("//*[@id='center_column']/ul/li[" + index + "]/div/div/div/a[1]/img")).Click();

                            Thread.Sleep(4500);
                            driver.SwitchTo().Frame(driver.FindElement(By.XPath("//iframe[@class='fancybox-iframe']")));
                            Thread.Sleep(1500);
                            driver.FindElement(By.XPath("//a[@id='wishlist_button']")).Click();
                            Thread.Sleep(1500);
                            String txt = driver.FindElement(By.XPath("//*[@id='product']/div[2]/div/div/div/div/p")).Text;
                            if (txt.Equals("Added to your wishlist.", StringComparison.OrdinalIgnoreCase))
                            {
                                Console.WriteLine("Added to Whishlist");
                                Thread.Sleep(3000);
                                driver.SwitchTo().DefaultContent();
                                Thread.Sleep(5000);

                                driver.FindElement(By.XPath("//body[@id='search']//a[@title='Close']")).Click();
                                //clicking cutomer link in header
                                driver.FindElement(By.XPath("//a[@title='View my customer account']")).Click();
                                Thread.Sleep(2500);
                                //clickin whislist
                                driver.FindElement(By.XPath("//span[text()='My wishlists']")).Click();
                                Thread.Sleep(2500);
                                //clicking view Button
                                driver.FindElement(By.XPath("//div[@id='block-history']/table/tbody//td[5]/a")).Click();
                                Thread.Sleep(1500);
                                int whislistcnt = driver.FindElements(By.XPath("//*[@id='block-order-detail']/div/div/ul/li")).Count;
                                if (whislistcnt == 0)
                                {
                                    Console.WriteLine("No item found in whislist");
                                    Assert.IsTrue(false);
                                }
                                else
                                {
                                    for (int whishindex = 1; whishindex <= whislistcnt; whishindex++)
                                    {
                                        String src1 = driver.FindElement(By.XPath("//*[@id='block-order-detail']/div/div/ul/li[" + whishindex + "]/div/div/div/a/img")).GetAttribute("src");
                                        if (src1.Equals(srcText, StringComparison.OrdinalIgnoreCase))
                                        {
                                            Console.WriteLine("Succesfully Item Found in whislist");
                                            driver.FindElement(By.XPath("//*[@id='block-order-detail']/div/div/ul/li[" + whishindex + "]/div/div//a[@title='Delete']")).Click();
                                            Thread.Sleep(1500);
                                            itemfound = "yes";
                                            break;
                                        }
                                    }
                                }
                                if (itemfound.Equals("yes"))
                                    break;
                            }
                        }
                    }
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
        }

        public static void AddtoWhishlist()
        {
            String itemfound = "";
            try
            {
                int count = driver.FindElements(By.XPath("//*[@id='center_column']/ul/li")).Count;
                {
                    if (count == 0)
                    {
                        Console.WriteLine("there is no item found to add to whishlist");
                    }
                    else
                    {
                        for (int index = 1; index <= count;)
                        {
                            String srcText = driver.FindElement(By.XPath("//*[@id='center_column']/ul/li[" + index + "]/div/div/div/a[1]/img")).GetAttribute("src");
                            String title = driver.FindElement(By.XPath("//*[@id='center_column']/ul/li[" + index + "]/div/div/div/a[1]/img")).GetAttribute("Title");
                            String description = driver.FindElement(By.XPath("//*[@id='center_column']/ul/li[1]//p")).Text;
                            String price = driver.FindElement(By.XPath("//*[@id='center_column']/ul/li[" + index + "]/div/div[2]/div[1]/span[2]")).Text;
                            driver.FindElement(By.XPath("//*[@id='center_column']/ul/li[" + index + "]/div/div/div/a[1]/img")).Click();

                            Thread.Sleep(4500);
                            driver.SwitchTo().Frame(driver.FindElement(By.XPath("//iframe[@class='fancybox-iframe']")));
                            Thread.Sleep(1500);
                            driver.FindElement(By.XPath("//a[@id='wishlist_button']")).Click();
                            Thread.Sleep(1500);
                            String txt = driver.FindElement(By.XPath("//*[@id='product']/div[2]/div/div/div/div/p")).Text;
                            if (txt.Equals("Added to your wishlist.", StringComparison.OrdinalIgnoreCase))
                            {
                                Console.WriteLine("Added to Whishlist");


                                driver.SwitchTo().DefaultContent();
                                Thread.Sleep(1500);

                                driver.FindElement(By.XPath("//body[@id='search']//a[@title='Close']")).Click();
                                //clicking cutomer link in header
                                driver.FindElement(By.XPath("//a[@title='View my customer account']")).Click();
                                Thread.Sleep(2500);
                                //clickin whislist
                                driver.FindElement(By.XPath("//span[text()='My wishlists']")).Click();
                                Thread.Sleep(2500);
                                //clicking view Button
                                driver.FindElement(By.XPath("//div[@id='block-history']/table/tbody//td[5]/a")).Click();
                                Thread.Sleep(1500);
                                int whislistcnt = driver.FindElements(By.XPath("//*[@id='block-order-detail']/div/div/ul/li")).Count;
                                if (whislistcnt == 0)
                                {
                                    Console.WriteLine("No item found in whislist");
                                    Assert.IsTrue(false);
                                }
                                else
                                {
                                    for (int whishindex = 1; whishindex <= whislistcnt; whishindex++)
                                    {
                                        String src1 = driver.FindElement(By.XPath("//*[@id='block-order-detail']/div/div/ul/li[" + whishindex + "]/div/div/div/a/img")).GetAttribute("src");
                                        if (src1.Equals(srcText, StringComparison.OrdinalIgnoreCase))
                                        {
                                            Console.WriteLine("Succesfully Item Found in whislist");
                                            driver.FindElement(By.XPath("//*[@id='block-order-detail']/div/div/ul/li[" + whishindex + "]/div/div//a[@title='Delete']")).Click();
                                            Thread.Sleep(1500);
                                            itemfound = "yes";
                                            break;
                                        }
                                    }
                                }
                                if (itemfound.Equals("yes"))
                                    break;
                            }
                        }
                    }
                }
            }
            catch (Exception)
            {
                Assert.IsTrue(false);
            }


        }
    }
}
