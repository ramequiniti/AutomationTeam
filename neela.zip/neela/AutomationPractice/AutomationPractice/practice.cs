﻿using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AutomationPractice
{
    class practice
    {
        public String mailid = "alphaori003@gmail.com";
        public String password = "Hello@123";
        [OneTimeSetUp]
        public void BrowserLaunch()
        {
            BusinessKeywords.LaunchBrowser();
           
        }
        [Test,Order(1)]
        public void Signinto_automationPractice()
        {
            BusinessKeywords.SigintoHomePage(mailid, password);

        }
        [Test,Order(2)]
        public void ProductSelection()
        {
          BusinessKeywords.SearchForDress();
         

        }
    }
}
