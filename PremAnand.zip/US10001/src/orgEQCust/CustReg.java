package orgEQCust;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Properties;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptException;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class CustReg {

	public static Properties prop = new Properties();
	static WebDriver driver;
	
	
	public static void main(String[] args) throws IOException, InterruptedException {
		// TODO Auto-generated method stub
		FileInputStream fsoprop = new FileInputStream("./resource/Prop.OR");
		prop.load(fsoprop);

		startDriver();
		login();		
		createUser();
	}
	
	public static void startDriver()
	{
		System.setProperty("webdriver.chrome.driver", "./lib/chromedriver.exe"); 
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		
	}	
	
	public static boolean login() throws InterruptedException
	{
		if(driver!=null)
		{
			driver.get(prop.getProperty("URL"));
		}
		else
		{
			driver = new ChromeDriver();
			driver.manage().window().maximize();
			driver.get(prop.getProperty("URL"));
		}
//		if((driver.findElement(By.xpath(prop.getProperty("Logo"))).isDisplayed()))
		if(isElementPresent(prop.getProperty("Logo"))!=null)
		{
			System.out.println("Application LogedIn Successfully");
			return true;
		}
		
		return false;
		
	}
	

	public static WebElement isElementPresent(String OR) throws InterruptedException
	{
		WebElement ele = null;
		Thread.sleep(1000);
		try
		{
		ele = driver.findElement(By.xpath(OR));
		if(ele.isDisplayed())
		{
			JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript("arguments[0].setAttribute('style', 'background: cyan; border: 2px solid red;');", ele);
//			ele.click();
			return ele;
		}
		}
		catch(Exception e)
		{
			ele = driver.findElement(By.xpath(OR));
			if(ele.isDisplayed())
			{
				return ele;
			}
		}
		return ele;	
		
	}
	
	
	
	public static void populateDropDown(String OR,String selText)
	{
		Select drpCountry = new Select(driver.findElement(By.xpath(OR)));
		drpCountry.selectByVisibleText(selText);
	}
	
	public static void inputText(String OR,String text) throws InterruptedException
	{
//		if(isElementPresent(prop.getProperty(OR))!=null)
//		{
			Thread.sleep(1000);
			driver.findElement(By.xpath(OR)).sendKeys(text);
//		}
	}
	
	public static void createUser() throws InterruptedException
	{
		WebElement element;
		if((element = isElementPresent(prop.getProperty("signInClk")))!=null)
		{
			element.click();
			System.out.println("SignIn Clicked to SignIn for Customers");
		}
		else
		{
			System.out.println("Page Not Loaded Existing Test");
			System.exit(1);
		}
		
		if(isElementPresent(prop.getProperty("emailTxt"))!=null)
		{
			
			Date date = new Date();  
		    SimpleDateFormat formatter = new SimpleDateFormat("dMyyhhmmss");  
		    String strDate= formatter.format(date);  
		    
		    
			inputText(prop.getProperty("emailTxt"), "Prem"+strDate+"@Yahoo.Com");
			isElementPresent(prop.getProperty("createAccBtn")).click();


		    
		    
			
			Thread.sleep(2000);
			inputText(prop.getProperty("firstNameTxt"), "Prem");
			inputText(prop.getProperty("lastNameTxt"), "John");
			
			inputText(prop.getProperty("emailPwdTxt"), "Auto1234");
			
			inputText(prop.getProperty("addressFirstNameTxt"), "Anand");
			
			inputText(prop.getProperty("addressLastNameTxt"), "Sam");
			
			inputText(prop.getProperty("addressAddressTxt"), "LittleMount");
			
			inputText(prop.getProperty("addressCityTxt"), "Chennai");
			
			populateDropDown(prop.getProperty("addressStateSel"), "California");
			
			inputText(prop.getProperty("addresspostCodeTxt"), "00000");
			
//			populateDropDown(prop.getProperty("addressCountrySel"), "United States");
			
			inputText(prop.getProperty("addressMPTxt"), "9841723456");
			
			
			isElementPresent(prop.getProperty("registerBtn")).click();
			
			
			
			
			
			
			
			
		}
		
		
		
		
	}
	
	
}
