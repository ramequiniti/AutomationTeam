import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;


public class Customer {
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub


System.setProperty(webdriver.chrome.driver, "C:\\Program Files (x86)\\Google\\Chrome\\Application.exe");
WebDriver driver=new ChromeDriver();
driver.get("http://automationpractice.com");
driver.getTitle();
driver.findElement(By.xpath("//*[@id='header']/div[2]/div/div/nav/div[1]/a")).click();
driver.findElement(By.xpath("//*[@id='email_create']")).sendKeys("sudharsani1994@gmail.com");
driver.findElement(By.xpath("//*[@id='SubmitCreate']")).click();
driver.findElement(By.xpath("//*[@id='customer_firstname']")).sendKeys("abd");;
driver.findElement(By.xpath("//*[@id='customer_lastname']")).sendKeys("gad");;
driver.findElement(By.xpath("//*[@id='passwd']")).sendKeys("welcome");;
driver.findElement(By.xpath("//*[@id='firstname']"));
driver.findElement(By.xpath("//*[@id='lastname']"));
driver.findElement(By.xpath("//*[@id='address1']"));
driver.findElement(By.xpath("//*[@id='city']"));

Select dropdown= new Select(driver.findElement(By.xpath("//*[@id='id_state']")));
dropdown.selectByIndex(1);


driver.findElement(By.xpath("//*[@id='//*[@id='postcode']']")).sendKeys("gh");
driver.findElement(By.xpath("//*[@id='//*[@id='phone_mobile']']")).sendKeys("7345678");
driver.findElement(By.xpath("//*[@id='//*[@id='alias']']")).sendKeys("gh");
driver.findElement(By.xpath("//*[@id='//*[@id='submitAccount']']")).click();
driver.findElement(By.xpath("*[@id='//*[@id='Add to cart']']")).click();

driver.close();





	}

}
